# SPDX-FileCopyrightText: 2014 Legrandin <helderijs@gmail.com>
# SPDX-License-Identifier: BSD-2-Clause

"""
EAX mode.
"""

from __future__ import annotations

from hmac import compare_digest
from typing import TYPE_CHECKING, Optional, Union, overload

__all__ = ["EaxMode"]

import struct
from binascii import unhexlify

from Crypto.Cipher._state_machine import Method
from Crypto.Hash import CMAC
from Crypto.Random import get_random_bytes
from Crypto.Util._raw_api import is_buffer
from Crypto.Util._typing import Buffer
from Crypto.Util.number import bytes_to_long
from Crypto.Util.strxor import strxor

if TYPE_CHECKING:
    from types import ModuleType


class EaxMode:
    """*EAX* mode.

    This is an Authenticated Encryption with Associated Data
    (`AEAD`_) mode. It provides both confidentiality and authenticity.

    The header of the message may be left in the clear, if needed,
    and it will still be subject to authentication.

    The decryption step tells the receiver if the message comes
    from a source that really knows the secret key.
    Additionally, decryption detects if any part of the message -
    including the header - has been modified or corrupted.

    This mode requires a *nonce*.

    This mode is only available for ciphers that operate on 64 or
    128 bits blocks.

    There are no official standards defining EAX.
    The implementation is based on `a proposal`__ that
    was presented to NIST.

    .. _AEAD: http://blog.cryptographyengineering.com/2012/05/how-to-choose-authenticated-encryption.html
    .. __: http://csrc.nist.gov/groups/ST/toolkit/BCM/documents/proposedmodes/eax/eax-spec.pdf
    """

    def __init__(
        self, factory: ModuleType, key: Buffer, nonce: Buffer, mac_len: int, cipher_params: dict
    ) -> None:
        """EAX cipher mode"""

        self.block_size = factory.block_size
        """The block size of the underlying cipher, in bytes."""

        self.nonce = bytes(nonce)
        """The nonce originally used to create the object."""

        self._mac_len = mac_len
        self._mac_tag: Optional[bytes] = None  # Cache for MAC tag

        # Allowed transitions after initialization
        self._next = [Method.UPDATE, Method.ENCRYPT, Method.DECRYPT, Method.DIGEST, Method.VERIFY]

        # MAC tag length
        if not (2 <= self._mac_len <= self.block_size):
            raise ValueError("'mac_len' must be at least 2 and not larger than %d" % self.block_size)

        # Nonce cannot be empty and must be a byte string
        if len(self.nonce) == 0:
            raise ValueError("Nonce cannot be empty in EAX mode")
        if not is_buffer(nonce):
            raise TypeError("nonce must be bytes, bytearray or memoryview")

        self._omac = [
            CMAC.new(
                key,
                b"\x00" * (self.block_size - 1) + struct.pack("B", i),
                ciphermod=factory,
                cipher_params=cipher_params,
            )
            for i in range(3)
        ]

        # Compute MAC of nonce
        self._omac[0].update(self.nonce)
        self._signer = self._omac[1]

        # MAC of the nonce is also the initial counter for CTR encryption
        counter_int = bytes_to_long(self._omac[0].digest())
        self._cipher = factory.new(
            key, factory.MODE_CTR, initial_value=counter_int, nonce=b"", **cipher_params
        )

    def update(self, assoc_data: Buffer) -> EaxMode:
        """Protect associated data

        If there is any associated data, the caller has to invoke
        this function one or more times, before using
        ``decrypt`` or ``encrypt``.

        By *associated data* it is meant any data (e.g. packet headers) that
        will not be encrypted and will be transmitted in the clear.
        However, the receiver is still able to detect any modification to it.

        If there is no associated data, this method must not be called.

        The caller may split associated data in segments of any size, and
        invoke this method multiple times, each time with the next segment.

        Args:
            assoc_data (bytes/bytearray/memoryview):
                A piece of associated data. There are no restrictions on its size.
        """

        if Method.UPDATE not in self._next:
            raise TypeError("update() can only be called immediately after initialization")

        self._next = [Method.UPDATE, Method.ENCRYPT, Method.DECRYPT, Method.DIGEST, Method.VERIFY]

        self._signer.update(assoc_data)
        return self

    @overload
    def encrypt(self, plaintext: Buffer) -> bytes: ...

    @overload
    def encrypt(self, plaintext: Buffer, output: Union[bytearray, memoryview]) -> None: ...

    @overload
    def encrypt(
        self, plaintext: Buffer, output: Optional[Union[bytearray, memoryview]] = None
    ) -> Optional[bytes]: ...

    def encrypt(
        self, plaintext: Buffer, output: Optional[Union[bytearray, memoryview]] = None
    ) -> Optional[bytes]:
        """Encrypt data with the key and the parameters set at initialization.

        A cipher object is stateful: once you have encrypted a message
        you cannot encrypt (or decrypt) another message using the same
        object.

        The data to encrypt can be broken up in two or
        more pieces and `encrypt` can be called multiple times.

        That is, the statement:

            >>> c.encrypt(a) + c.encrypt(b)

        is equivalent to:

             >>> c.encrypt(a+b)

        This function does not add any padding to the plaintext.

        Args:
            plaintext (bytes/bytearray/memoryview):
                The piece of data to encrypt.
                It can be of any length.
        Keyword Args:
            output (bytearray/memoryview):
                The location where the ciphertext must be written to.
                If ``None``, the ciphertext is returned.
        Returns:
            If ``output`` is ``None``, the ciphertext as ``bytes``.
            Otherwise, ``None``.
        """

        if Method.ENCRYPT not in self._next:
            raise TypeError("encrypt() can only be called after initialization or an update()")
        self._next = [Method.ENCRYPT, Method.DIGEST]
        ct = self._cipher.encrypt(plaintext, output=output)
        if output is None:
            self._omac[2].update(ct)
        else:
            self._omac[2].update(output)
        return ct

    @overload
    def decrypt(self, ciphertext: Buffer) -> bytes: ...

    @overload
    def decrypt(self, ciphertext: Buffer, output: Union[bytearray, memoryview]) -> None: ...

    @overload
    def decrypt(
        self, ciphertext: Buffer, output: Optional[Union[bytearray, memoryview]] = None
    ) -> Optional[bytes]: ...

    def decrypt(
        self, ciphertext: Buffer, output: Optional[Union[bytearray, memoryview]] = None
    ) -> Optional[bytes]:
        """Decrypt data with the key and the parameters set at initialization.

        A cipher object is stateful: once you have decrypted a message
        you cannot decrypt (or encrypt) another message with the same
        object.

        The data to decrypt can be broken up in two or
        more pieces and `decrypt` can be called multiple times.

        That is, the statement:

            >>> c.decrypt(a) + c.decrypt(b)

        is equivalent to:

             >>> c.decrypt(a+b)

        This function does not remove any padding from the plaintext.

        Args:
            ciphertext (bytes/bytearray/memoryview):
                The piece of data to decrypt.
                It can be of any length.
        Keyword Args:
            output (bytearray/memoryview):
                The location where the plaintext must be written to.
                If ``None``, the plaintext is returned.
        Returns:
            If ``output`` is ``None``, the plaintext as ``bytes``.
            Otherwise, ``None``.
        """

        if Method.DECRYPT not in self._next:
            raise TypeError("decrypt() can only be called after initialization or an update()")
        self._next = [Method.DECRYPT, Method.VERIFY]
        self._omac[2].update(ciphertext)
        return self._cipher.decrypt(ciphertext, output=output)

    def digest(self) -> bytes:
        """Compute the *binary* MAC tag.

        The caller invokes this function at the very end.

        This method returns the MAC that shall be sent to the receiver,
        together with the ciphertext.

        Returns:
            the MAC, as a byte string.
        """

        if Method.DIGEST not in self._next:
            raise TypeError("digest() cannot be called when decrypting or validating a message")
        self._next = [Method.DIGEST]

        if not self._mac_tag:
            tag = b"\x00" * self.block_size
            for i in range(3):
                tag = strxor(tag, self._omac[i].digest())
            self._mac_tag = tag[: self._mac_len]

        return self._mac_tag

    def hexdigest(self) -> str:
        """Compute the *printable* MAC tag.

        This method is like `digest`.

        Returns:
            the MAC, as a hexadecimal string.
        """
        return self.digest().hex()

    def verify(self, received_mac_tag: Buffer) -> None:
        """Validate the *binary* MAC tag.

        The caller invokes this function at the very end.

        This method checks if the decrypted message is indeed valid
        (that is, if the key is correct) and it has not been
        tampered with while in transit.

        Args:
            received_mac_tag (bytes/bytearray/memoryview):
                This is the *binary* MAC, as received from the sender.
        Raises:
            ValueError:
                if the MAC does not match. The message has been tampered with
                or the key is incorrect.
        """

        if Method.VERIFY not in self._next:
            raise TypeError("verify() cannot be called when encrypting a message")
        self._next = [Method.VERIFY]

        if not self._mac_tag:
            tag = b"\x00" * self.block_size
            for i in range(3):
                tag = strxor(tag, self._omac[i].digest())
            self._mac_tag = tag[: self._mac_len]

        if not compare_digest(self._mac_tag, received_mac_tag):
            raise ValueError("MAC check failed")

    def hexverify(self, hex_mac_tag: str) -> None:
        """Validate the *printable* MAC tag.

        This method is like `verify`.

        Args:
            hex_mac_tag (string):
                This is the *printable* MAC, as received from the sender.
        Raises:
            ValueError:
                if the MAC does not match. The message has been tampered with
                or the key is incorrect.
        """

        self.verify(unhexlify(hex_mac_tag))

    @overload
    def encrypt_and_digest(self, plaintext: Buffer) -> tuple[bytes, bytes]: ...

    @overload
    def encrypt_and_digest(
        self, plaintext: Buffer, output: Union[bytearray, memoryview]
    ) -> tuple[None, bytes]: ...

    def encrypt_and_digest(
        self, plaintext: Buffer, output: Optional[Union[bytearray, memoryview]] = None
    ) -> tuple[Optional[bytes], bytes]:
        """Perform encrypt() and digest() in one step.

        Args:
            plaintext (bytes/bytearray/memoryview):
                The piece of data to encrypt.
        Keyword Args:
            output (bytearray/memoryview):
                The location where the ciphertext must be written to.
                If ``None``, the ciphertext is returned.
        Returns:
            The tuple ``(ciphertext, tag)``, both ``bytes``.
            The ciphertext is ``None`` when the ``output`` parameter
            specified a location for the result.
        """

        return self.encrypt(plaintext, output=output), self.digest()

    @overload
    def decrypt_and_verify(self, ciphertext: Buffer, received_mac_tag: Buffer) -> bytes: ...

    @overload
    def decrypt_and_verify(
        self, ciphertext: Buffer, received_mac_tag: Buffer, output: Union[bytearray, memoryview]
    ) -> None: ...

    def decrypt_and_verify(
        self,
        ciphertext: Buffer,
        received_mac_tag: Buffer,
        output: Optional[Union[bytearray, memoryview]] = None,
    ) -> Optional[bytes]:
        """Perform decrypt() and verify() in one step.

        Args:
            ciphertext (bytes/bytearray/memoryview):
                The piece of data to decrypt.
            received_mac_tag (bytes/bytearray/memoryview):
                This is the *binary* MAC, as received from the sender.
        Keyword Args:
            output (bytearray/memoryview):
                The location where the plaintext must be written to.
                If ``None``, the plaintext is returned.
                If the MAC does not match, the location is filled with zeroes.
        Returns:
            the plaintext as ``bytes`` or ``None`` when the ``output``
            parameter specified a location for the result.
        Raises:
            ValueError:
                if the MAC does not match. The message has been tampered with
                or the key is incorrect.
        """

        pt = self.decrypt(ciphertext, output=output)
        try:
            self.verify(received_mac_tag)
        except ValueError:
            # Do not leave unauthenticated plaintext in the output
            if output is not None:
                output[:] = bytes(len(output))
            raise
        return pt


def _create_eax_cipher(factory, **kwargs):
    """Create a new block cipher, configured in EAX mode.

    Args:
        factory (module):
            A symmetric cipher module from `Crypto.Cipher` (like
            `Crypto.Cipher.AES`).

    Keyword Args:
        key (bytes/bytearray/memoryview):
            The secret key to use in the symmetric cipher.

        nonce (bytes/bytearray/memoryview):
            A value that must never be reused for any other encryption.
            There are no restrictions on its length, but it is recommended to use
            at least 16 bytes.

            The nonce shall never repeat for two different messages encrypted with
            the same key, but it does not need to be random.

            If not specified, a 16 byte long random string is used.

        mac_len (integer):
            Length of the MAC, in bytes. It must be no larger than the cipher
            block bytes (which is the default).
    """

    try:
        key = kwargs.pop("key")
        nonce = kwargs.pop("nonce", None)
        if nonce is None:
            nonce = get_random_bytes(16)
        mac_len = kwargs.pop("mac_len", factory.block_size)
    except KeyError as e:
        raise TypeError("Missing parameter: " + str(e))

    return EaxMode(factory, key, nonce, mac_len, kwargs)
